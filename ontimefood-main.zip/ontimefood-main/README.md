On Time Food is a web application designed to pre-order food and a unique feature it consists of is rescheduling!!
It was completely designed with python both for front-end and back-end!!
The main file to run in the above repository is "food1.py", 
The logins are given defaultly using mysql workbench!!
Since, it was exclusively designed for a particular area of faculty and students, registration was not a deal at all!!
